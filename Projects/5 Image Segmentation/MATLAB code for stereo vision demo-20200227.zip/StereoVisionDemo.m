% simple stereo vision system using cross correlation.
% Extract a template patch from the left.
% Scan through the right image and do normalized cross-correlation to match
% to the left. Accept a match if score is greater than a threshold.

clear all
close all

% parameters
W = 16;  % size of template (2W+1 x 2W+1)
DH = 50; % disparity horizontal search limit
DV = 5;  % disparity vertical search limit 

Iright = im2double(imread('right.png'));
Ileft = im2double(imread('left.png'));
figure(1), imshow(Ileft, []), title('left image')
figure(2), imshow(Iright, []), title('right image')

% calculate disparity at a set of discrete points
xborder = W+DH+1;
yborder = W+DV+1;
xTsize = W+DH; % horizontal template size is 2*xTsize+1
yTsize = W+DV; % vertical template size is 2*yTsize+1

npts = 0; % number of found disparity points

[m,n] = size(Ileft); % dimension of the image
for x=xborder:W:n-xborder
    for y=yborder:W:m-yborder
        % extract a template from the left image centered at x,y with the
        % size of (2W+1)x(2W+1)
        figure(1), hold on, plot(x,y, 'rd'), hold off;
        T = imcrop(Ileft, [x-W y-W 2*W 2*W]);
        %figure(3), imshow(T,[]), title('Template')
        
        % Search for match in the right image, im a region centered at x,y
        % with the size of (2*xTsize+1)x(2*yTSize+1)
        IR = imcrop(Iright, [x-xTsize y-yTsize 2*xTsize 2*yTsize]);
        %figure(4), imshow(IR, []), title('Search area')
        
        % The cross-correlation score image is the size of IR, expanded by W in 
        % each direction
        ccscores = normxcorr2(T,IR);
        %figure(5), imshow(ccscores,[]), title('Cross-Correlation map');
        
        % Get the max_score and location of the peak in the correlation map
        [max_score, maxindex] = max(ccscores(:));
        % Find the subscripts of peak in the 2D array
        [ypeak, xpeak] = ind2sub(size(ccscores), maxindex);
        %hold on, plot(xpeak, ypeak,'rd'), hold off;
        
        % if scores too low, ignore this point
        if max_score < 0.05 continue; end
        
        % They are the coordinates of the peak in the search image
        ypeak = ypeak - W;
        xpeak = xpeak - W;
        %figure(4), hold on, plot(xpeak, ypeak,'rd'), hold off;
        
        % These are the coordinates in the full sized right image
        xpeak = xpeak + (x-xTsize);
        ypeak = ypeak + (y-yTsize);
        %figure(2), hold on, plot(xpeak, ypeak, 'rd'), hold off;
        
        % Save a point in a list, along with its disparity
        npts = npts+1;
        xPt(npts) = x;
        yPt(npts) = y;
        dPt(npts) = xpeak-x; % disparity is xright-xleft
        
        %pause
    end
end

% 3D plot the object
figure, plot3(xPt, yPt, dPt, 'o');
        